#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OpenRice 评论关键词与情感词云。

在编辑器中直接点击「运行」，即可读取 data 文件夹并生成最终图片。
也可以在终端运行：python3 openrice_sentiment_cloud.py

输出保存在 output 文件夹：
    情感词云与大字图.png  —— 词云与三类大字图合并在一张图
    总情感词云.png        —— 独立词云
    情感大字图.png        —— 独立大字图
    phrase_labels.csv     —— 评论关键词、情感与对应原文
    phrase_frequencies.csv —— 关键词频次
    summary.json          —— 数据统计

绿色表示好评，红色表示差评，灰蓝色表示中性评价。
词语大小对应提及该短语的评论数量；同条评论同个短语计一次。
"""
import argparse
import csv
import hashlib
import html
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from collections import Counter


os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir()) / 'openrice_plot_cache'))
try:
    from PIL import Image, ImageDraw, ImageFont
    from wordcloud import WordCloud
except ImportError as exc:
    raise ImportError(
        f"缺少绘图依赖：{exc}\n"
        f"请在当前解释器安装：{sys.executable} -m pip install pillow wordcloud"
    ) from exc
from PIL import Image, ImageDraw, ImageFont
from wordcloud import WordCloud



COLORS = {'好': '#16866C', '坏': '#D5544D', '中性': '#71809B'}
INK = '#172B40'
BACKGROUND = '#F5F7FA'
ASPECTS = {
    '咖啡': r'咖啡|coffee|latte|拿[鐵铁]|美式|cappuccino|flat\s*white',
    '飲品': r'[飲饮]品|[飲饮]料|奶茶|抹茶|果茶|朱古力|[檸柠]檬茶|drinks?',
    '食物': r'食物|食材|食品|餐[點点]|主食|意粉|意[麵面]|[漢汉]堡|牛[扒排肉]|炸[雞鸡]|food|pasta|burger',
    '甜品': r'甜品|甜[點点]|蛋糕|班戟|梳乎厘|窩夫|[鬆松]餅|dessert|cake|pancake|waffle',
    '環境': r'[環环]境|[氣气]氛|氛[圍围]|店[內内]|[裝装][修潢]|座位|空[間间]|ambien[ct]e|atmosphere|decor',
    '服務': r'服[務务]|[態态]度|[員员]工|侍[應应]|店[員员]|service|staff',
    '價格': r'[價价][格錢钱]|[價价]位|收[費费]|price|pricing',
    '性價比': r'性[價价]比|cp\s*值|cp\s*value|value\s*for\s*money',
    '份量': r'[份分]量|portions?',
    '等候': r'等[候待]|排[隊队]|[出上]餐|waiting|queue',
    '位置': r'位置|地[點点]|交通|location',
}
# 将相近表述归纳成完整评价短语，便于汇总展示。
PREDICATES = {
    '咖啡': [('香醇','好',r'香醇|香[濃浓]|醇厚|香滑|[順顺]滑|[濃浓]郁|rich|smooth|aromatic'),('好喝','好',r'好[飲饮喝]|好味|好正|出色|不[錯错]|唔[錯错]|delicious|great|excellent|tasty'),('難喝','坏',r'[難难][飲饮喝]|苦[澀涩]|淡而[無无]味|watery|terrible'),('太苦','坏',r'太苦|[過过]苦|too bitter'),('太酸','坏',r'太酸|[過过]酸|too sour'),('一般','中性',r'一般|普通|[無无]功[無无][過过]|average|ordinary|okay|ok\b')],
    '飲品': [('好喝','好',r'好[飲饮喝]|好味|香[濃浓]|清新|清爽|[順顺]滑|不[錯错]|唔[錯错]|delicious|tasty|great'),('太甜','坏',r'太甜|[過过]甜|甜到漏|too sweet'),('難喝','坏',r'[難难][飲饮喝]|淡而[無无]味|watery|terrible'),('一般','中性',r'一般|普通|average|ordinary|okay')],
    '食物': [('好吃','好',r'好食|好吃|好味|美味|[鮮鲜]美|[鮮鲜]甜|嫩滑|[鮮鲜]嫩|[鬆松]脆|出色|不[錯错]|唔[錯错]|delicious|tasty|excellent'),('難吃','坏',r'[難难]食|[難难]吃|[難难]入口|[難难]以下[嚥咽]|[冇無没]味|差[勁劲]|terrible|bland'),('太鹹','坏',r'太[鹹咸]|[過过][鹹咸]|死[鹹咸]|too salty'),('一般','中性',r'一般|普通|[無无]功[無无][過过]|中[規规]中矩|average|ordinary|okay')],
    '甜品': [('好吃','好',r'好食|好吃|好味|美味|[鬆松][軟软]|綿密|入口即化|不[錯错]|唔[錯错]|delicious|tasty|excellent'),('太甜','坏',r'太甜|[過过]甜|甜到漏|too sweet'),('難吃','坏',r'[難难]食|[難难]吃|差[勁劲]|terrible'),('一般','中性',r'一般|普通|average|ordinary|okay')],
    '環境': [('舒適','好',r'舒[適适服]|[開开]揚|[寬宽]敞|不[錯错]|唔[錯错]|comfortable|spacious|cozy|cosy'),('安靜','好',r'安[靜静]|[寧宁][靜静]|清[靜静]|quiet|peaceful'),('優美','好',r'[優优]美|漂亮|[靚靓]|[優优]雅|雅致|beautiful|lovely'),('嘈雜','坏',r'嘈[雜杂]|嘈|吵|[喧嘩哗]|noisy|loud'),('擠迫','坏',r'[擠挤]迫|[擁拥][擠挤]|[狹狭]窄|侷促|局促|cramped|crowded'),('一般','中性',r'一般|普通|average|ordinary|okay')],
    '服務': [('好','好',r'好|友[善好]|[親亲]切|[熱热]情|[細细]心|[貼贴]心|周到|[殷慇]勤|有[禮礼]|[專专][業业]|不[錯错]|唔[錯错]|good|great|friendly|attentive|helpful'),('差','坏',r'差|[惡恶]劣|冷[淡漠]|[無无冇][禮礼]|粗[魯鲁]|怠慢|rude|poor|bad|unfriendly'),('一般','中性',r'一般|普通|average|ordinary|okay')],
    '價格': [('合理','好',r'合理|公道|[實实]惠|便宜|抵[食飲饮]|相宜|affordable|reasonable|cheap'),('偏貴','坏',r'[貴贵]|昂[貴贵]|高昂|expensive|overpriced|pricey'),('適中','中性',r'[適适]中|中等|一般|average|moderate')],
    '性價比': [('高','好',r'高|不[錯错]|唔[錯错]|抵|good|great|excellent'),('低','坏',r'低|差|唔抵|不高|poor|bad'),('一般','中性',r'一般|普通|average|okay')],
    '份量': [('充足','好',r'足|大|多|[豐丰]富|generous|large|big'),('偏少','坏',r'少|小|不足|small|tiny'),('適中','中性',r'[適适]中|[剛刚]好|啱啱好|一般|moderate')],
    '等候': [('時間長','坏',r'耐|[長长]|慢|久|long|slow'),('時間短','好',r'快|短|迅速|quick|fast'),('時間一般','中性',r'一般|普通|average')],
    '位置': [('方便','好',r'方便|便利|易[搵找]|convenient|accessible'),('偏僻','坏',r'偏僻|[難难][搵找]|不便|唔方便|inconvenient'),('一般','中性',r'一般|average')],
}
NEGATIVE_PREFIX = re.compile(r'(?:不[是算太]?|[沒没]有?|[無无]|並非|并非|唔[係系算太]?|未算|not\s+|isn.t\s+|wasn.t\s+|no\s+)$', re.I)
SPLIT = re.compile(r'[，,。.!！?？;；\n]|但[係是]?|不過|不过|然而|\bbut\b|\bhowever\b', re.I)
ASPECT_PATTERNS = {a: re.compile(p,re.I) for a,p in ASPECTS.items()}
PREDICATE_PATTERNS = {a: [(label,s,re.compile(p,re.I)) for label,s,p in ps] for a,ps in PREDICATES.items()}
NEGATE_GOOD = {'好':'差','好喝':'不好喝','好吃':'不好吃','充足':'偏少','高':'低','合理':'不合理','舒適':'不舒適','安靜':'嘈雜','優美':'不美觀','方便':'不方便','香醇':'不香醇','時間短':'時間長'}
NEGATE_BAD = {'差':'好','偏少':'充足','偏貴':'合理','低':'高','太甜':'甜度適中','太鹹':'鹹度適中','太苦':'苦度適中','太酸':'酸度適中','嘈雜':'安靜','擠迫':'不擠迫','偏僻':'不偏僻','時間長':'時間短','難喝':'不難喝','難吃':'不難吃'}


def extract_phrases(text):
    """识别评价对象及其描述，保留关键词、情感、主题和原文片段。"""
    text = html.unescape(re.sub(r'<[^>]+>|\[/?(?:url|img)[^\]]*\]', '', text, flags=re.I))
    found = {}
    for clause in SPLIT.split(text):
        clause = clause.strip()
        if not clause:
            continue
        aspects = sorted((m.start(),m.end(),a) for a,pat in ASPECT_PATTERNS.items() for m in pat.finditer(clause))
        for i,(start,end,aspect) in enumerate(aspects):
            stop = aspects[i+1][0] if i+1<len(aspects) else len(clause)
            region = clause[end:min(stop,end+24)]
            candidates = []
            for label,sentiment,pat in PREDICATE_PATTERNS[aspect]:
                for m in pat.finditer(region):
                    if m.start()>12:
                        continue
                    suffix = label
                    actual_sentiment = sentiment
                    if NEGATIVE_PREFIX.search(region[:m.start()].rstrip()):
                        if sentiment=='好':
                            suffix=NEGATE_GOOD.get(label,'不'+label);actual_sentiment='坏'
                        elif sentiment=='坏':
                            suffix=NEGATE_BAD.get(label,'不'+label);actual_sentiment='好'
                        else:
                            continue
                    candidates.append((m.start(),-len(m.group()),aspect+suffix,actual_sentiment,m.end()))
            if candidates:
                _,_,phrase,sentiment,last = sorted(candidates)[0]
                evidence = clause[max(0,start-5):min(len(clause),end+last+5)].strip()
                found.setdefault((phrase,sentiment),(aspect,evidence))
    # 优先覆盖不同主题，再补充同一主题中的其他评价。
    results=[];topics=set()
    for (phrase,sentiment),(topic,evidence) in found.items():
        if topic not in topics:
            results.append((phrase,sentiment,topic,evidence));topics.add(topic)
    for (phrase,sentiment),(topic,evidence) in found.items():
        item=(phrase,sentiment,topic,evidence)
        if item not in results:
            results.append(item)
    return results[:5]


def get_font(path=None):
    candidates = [path] if path else []
    candidates += [str(Path(__file__).resolve().parent/'chinese.ttf'),'/System/Library/Fonts/PingFang.ttc','/System/Library/Fonts/STHeiti Medium.ttc','/System/Library/Fonts/Hiragino Sans GB.ttc','C:/Windows/Fonts/msyh.ttc','C:/Windows/Fonts/simhei.ttf','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc']
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return str(Path(candidate).resolve())
    raise SystemExit('请通过 --font 指定中文字体，或将字体文件命名为 chinese.ttf 放在代码旁。')


def make_figures(frequencies, stats, output, font_path):
    def font(size):
        return ImageFont.truetype(font_path,size)
    def text(draw,xy,value,size=30,color=INK):
        draw.text(xy,value,font=font(size),fill=color)
    LABELS_EN = {'好': 'Positive', '坏': 'Negative', '中性': 'Neutral'}
    selected=[]
    for sentiment in COLORS:
        selected.extend([(key,n) for key,n in frequencies.most_common() if key[1]==sentiment][:80])
    weights={key[0]:n for key,n in selected}
    sentiments={key[0]:key[1] for key,n in selected}
    wc=WordCloud(width=2280,height=1030,font_path=font_path,background_color='white',
        max_words=240,prefer_horizontal=.9,relative_scaling=.5,min_font_size=15,
        max_font_size=160,margin=10,random_state=42,collocations=False,
        color_func=lambda word,**kwargs:COLORS[sentiments[word]])
    cloud=wc.generate_from_frequencies(weights).to_image()
    cloud.save(output/'总情感词云.png',dpi=(240,240))
    big=Image.new('RGB',(2400,1030),BACKGROUND);draw=ImageDraw.Draw(big)
    text(draw,(64,32),'High-Frequency Reviews · Big Text',45)
    text(draw,(64,98),'Top keywords for Positive, Negative, and Neutral reviews',27,'#66778B')
    for column,sentiment in enumerate(COLORS):
        x=60+column*780;color=COLORS[sentiment]
        draw.rounded_rectangle((x,160,x+740,995),radius=22,fill='white')
        draw.rounded_rectangle((x+28,187,x+38,242),radius=4,fill=color)
        text(draw,(x+58,183),LABELS_EN[sentiment],40,color)
        count=sum(n for key,n in frequencies.items() if key[1]==sentiment)
        text(draw,(x+32,258),f'{count:,} phrase mentions',25,'#66778B')
        labels=[(key[0],n) for key,n in frequencies.most_common() if key[1]==sentiment][:7]
        for index,(phrase,n) in enumerate(labels):
            y=330+index*88;size=int(32+24*(n/labels[0][1])**.5)
            while font(size).getlength(phrase)>490:
                size-=1
            text(draw,(x+30,y),phrase,size,color)
            value=f'{n:,}'
            text(draw,(x+700-font(27).getlength(value),y+15),value,27,'#66778B')
        if not labels:
            text(draw,(x+32,350),'No relevant reviews yet',30,'#66778B')
    big.save(output/'情感大字图.png',dpi=(240,240))
    combined=Image.new('RGB',(2400,2490),BACKGROUND);draw=ImageDraw.Draw(combined)
    text(draw,(60,35),'OPENRICE  /  Customer Review Overview',32,'#66778B')
    text(draw,(60,95),'One review, one emotion',68)
    text(draw,(60,195),f"{stats['reviews']:,} reviews  ·  {stats['shops_with_reviews']:,} shops with reviews",30,'#66778B')
    for x,(sentiment,color) in zip([60,330,600],COLORS.items()):
        draw.ellipse((x,270,x+24,294),fill=color)
        text(draw,(x+38,259),sentiment,30,color)
    draw.rounded_rectangle((50,320,2350,1370),radius=24,fill='white')
    combined.paste(cloud,(60,330));combined.paste(big,(0,1390))
    text(draw,(60,2430),'The larger the word, the more frequently it is mentioned; each phrase in a review is counted once.',28,'#66778B')
    combined.save(output/'情感词云与大字图.png',dpi=(240,240))

def _extract_frequencies(reviews_df):
    """从评论 DataFrame 抽取短语频次 + 统计。NaN 安全。"""
    def _txt(v):
        if v is None:
            return ""
        if isinstance(v, float) and v != v:   # NaN 检测
            return ""
        s = str(v).strip()
        return "" if s.lower() in ("nan", "none", "<na>") else s

    frequencies = Counter()
    seen = set()
    shop_set = set()

    for row in reviews_df.to_dict("records"):
        review = (_txt(row.get("text"))
                  or _txt(row.get("body"))
                  or _txt(row.get("original_review")))
        if not review:
            continue

        rid = _txt(row.get("review_id"))
        if not rid:
            rid = hashlib.sha256(
                (_txt(row.get("poi_id")) + "\0" + review).encode()
            ).hexdigest()
        if rid in seen:
            continue
        seen.add(rid)

        poi_id = _txt(row.get("poi_id"))
        if poi_id:
            shop_set.add(poi_id)

        for phrase, sentiment, _topic, _evidence in extract_phrases(review):
            frequencies[(phrase, sentiment)] += 1

    stats = {
        "reviews": len(seen),
        "shops_with_reviews": len(shop_set),
        "duplicate_rows_removed": 0,
        "phrase_mentions": sum(frequencies.values()),
        "sentiment_phrase_mentions": {
            s: sum(n for key, n in frequencies.items() if key[1] == s)
            for s in COLORS
        },
    }
    return frequencies, stats


def generate_wordcloud_for_district(
    district_en,
    reviews_df,
    shops_df,
    base_output="output/wordclouds",
    font_path=None,
):
    """
    按 district_en 过滤评论并生成一张词云图。

    Parameters
    ----------
    district_en : str            如 "Sheung Wan"，必须和 shops_df["district_en"] 一致
    reviews_df  : DataFrame      reviews.csv 的子集或全量，需有 poi_id 和 text/body 列
    shops_df    : DataFrame      shops.csv，需有 poi_id 和 district_en 列
    base_output : str | Path     根目录；实际写到 base_output/{slug}/
    font_path   : str | None     None 时自动找（get_font）

    Returns
    -------
    Path | None    生成的主图路径；该区无评论时返回 None
    """
    if font_path is None:
        font_path = get_font()

    if "district_en" not in shops_df.columns or "poi_id" not in shops_df.columns:
        return None

    poi_ids = set(
        shops_df.loc[shops_df["district_en"] == district_en, "poi_id"].astype(str)
    )
    if not poi_ids:
        return None

    sub = reviews_df[reviews_df["poi_id"].astype(str).isin(poi_ids)]
    if sub.empty:
        return None

    frequencies, stats = _extract_frequencies(sub)
    if not frequencies:
        return None

    slug = re.sub(r"[^a-z0-9]+", "_", district_en.lower()).strip("_")
    out_dir = Path(base_output) / slug
    out_dir.mkdir(parents=True, exist_ok=True)

    make_figures(frequencies, stats, out_dir, font_path)
    return out_dir / "情感词云与大字图.png"


def main():
    HERE = Path(__file__).resolve().parent
    PROJECT_ROOT = HERE.parent
    base=PROJECT_ROOT
    parser=argparse.ArgumentParser(description='读取OpenRice评论，一次生成情感词云与大字图。')
    parser.add_argument('--data-dir',type=Path,default=base/'data')
    parser.add_argument('--output-dir',type=Path,default=base/'output')
    parser.add_argument('--font')
    args=parser.parse_args()
    source=next((p for p in [args.data_dir/'reviews.csv',args.data_dir/'combined.csv',base/'reviews.csv',base/'combined.csv'] if p.is_file()),None)
    if source is None:
        raise SystemExit('请把 reviews.csv 或 combined.csv 放在代码旁的 data 文件夹。')
    font_path=get_font(args.font)
    output=args.output_dir;output.mkdir(parents=True,exist_ok=True)
    frequencies=Counter();seen=set();shops=set();duplicate_rows=0
    fields=['review_id','poi_id','shop_name','original_review','keyword','topic','sentiment','sentiment_score','evidence']
    print('正在读取评论并生成关键词与情感统计……',flush=True)
    with source.open(encoding='utf-8-sig',newline='') as f, (output/'phrase_labels.csv').open('w',encoding='utf-8-sig',newline='') as target:
        reader=csv.DictReader(f)
        if not set(reader.fieldnames or []) & {'text','body','original_review'}:
            raise SystemExit('数据需要包含 text、body 或 original_review 文本列。')
        writer=csv.DictWriter(target,fieldnames=fields);writer.writeheader()
        for row in reader:
            review=(row.get('text') or row.get('body') or row.get('original_review') or '').strip()
            review_id=row.get('review_id') or hashlib.sha256((str(row.get('poi_id',''))+'\0'+review).encode()).hexdigest()
            if review_id in seen:
                duplicate_rows+=1;continue
            seen.add(review_id)
            if row.get('poi_id'):
                shops.add(row['poi_id'])
            for phrase,sentiment,topic,evidence in extract_phrases(review):
                frequencies[(phrase,sentiment)]+=1
                writer.writerow(dict(review_id=review_id,poi_id=row.get('poi_id',''),shop_name=row.get('shop_name',''),original_review=review,keyword=phrase,topic=topic,sentiment=sentiment,sentiment_score={'好':1,'坏':-1,'中性':0}[sentiment],evidence=evidence))
            if len(seen)%5000==0:
                print(f'已处理 {len(seen):,} 条评论',flush=True)
    if not frequencies:
        raise SystemExit('没有可绘图的评价短语，请检查输入数据。')
    with (output/'phrase_frequencies.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(['keyword','sentiment','review_mentions'])
        writer.writerows((key[0],key[1],n) for key,n in frequencies.most_common())
    stats={'source':str(source.resolve()),'reviews':len(seen),'shops_with_reviews':len(shops),'duplicate_rows_removed':duplicate_rows,'phrase_mentions':sum(frequencies.values()),'sentiment_phrase_mentions':{s:sum(n for key,n in frequencies.items() if key[1]==s) for s in COLORS}}
    (output/'summary.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    print('正在绘制词云与大字图……',flush=True)
    make_figures(frequencies,stats,output,font_path)
    print(f"完成！已处理 {len(seen):,} 条评论。",flush=True)
    print('最终图片：'+str((output/'情感词云与大字图.png').resolve()))


if __name__=='__main__':
    main()
